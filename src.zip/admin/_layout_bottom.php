<?php require_once __DIR__ . '/../libs/admin_guard.php'; ?>

</main>
  <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
