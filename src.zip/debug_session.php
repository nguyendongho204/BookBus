<?php
require __DIR__ . '/includes/session_bootstrap.php';
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
